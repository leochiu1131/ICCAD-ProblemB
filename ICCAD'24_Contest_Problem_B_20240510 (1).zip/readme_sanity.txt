## Brief
"sanity" is an utility sanity checker provided by ICCAD'24 Contest Problem B. This checker checks the mapping connection and all other net and pin relative output integrity.
## Usage 
$ ./sanity <testcase> <output>
## Example
$ ./sanity sampleCase sampleOutput